word = input("Enter the word: ").lower()

def reversal(org_word):
    if len(org_word) <= 1:
        return org_word
    else:
       return org_word[len(org_word)-1] + reversal(org_word[0:len(org_word)-1])

print(f"Reversal using recusrsion {reversal(word)}")

reverse_str = word[::-1]
print(f"Reversal using slice {reversal(word)}")
